const express = require('express');
const cors = require('cors');
const { PrismaClient } = require('@prisma/client');

const prisma = new PrismaClient();
const app = express();

app.use(cors());
app.use(express.json());

// --- ROUTES: CRM DEALS ---

// Get all deals
app.get('/api/deals', async (req, res) => {
  try {
    const deals = await prisma.deal.findMany({
      include: { contact: true, user: true },
    });
    res.json(deals);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create new deal
app.post('/api/deals', async (req, res) => {
  const { title, value, stage, contactId, userId } = req.body;
  try {
    const deal = await prisma.deal.create({
      data: { title, value: parseFloat(value), stage, contactId, userId },
    });
    res.status(201).json(deal);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Update deal stage (Kanban Drag and Drop)
app.patch('/api/deals/:id/stage', async (req, res) => {
  const { id } = req.params;
  const { stage } = req.body;
  try {
    const updatedDeal = await prisma.deal.update({
      where: { id },
      data: { stage },
    });
    res.json(updatedDeal);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// --- ROUTES: BOOKINGS & APPOINTMENTS ---

// Get all appointments
app.get('/api/appointments', async (req, res) => {
  try {
    const appointments = await prisma.appointment.findMany({
      include: { contact: true, staff: true },
    });
    res.json(appointments);
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
});

// Create appointment
app.post('/api/appointments', async (req, res) => {
  const { startTime, endTime, contactId, staffId } = req.body;
  try {
    const appointment = await prisma.appointment.create({
      data: {
        startTime: new Date(startTime),
        endTime: new Date(endTime),
        contactId,
        staffId,
      },
    });
    res.status(201).json(appointment);
  } catch (error) {
    res.status(400).json({ error: error.message });
  }
});

// Start Server
const PORT = process.env.PORT || 5000;
app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
