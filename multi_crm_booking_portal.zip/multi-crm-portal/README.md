# Multi-CRM, Booking, Appointment & Company Portal

This repository contains the full source code for the Multi-CRM, Booking, Appointment, and Company Operations Portal.

## Folder Structure

```
├── frontend/
│   └── index.html          # HTML5 + CSS + JavaScript SPA Frontend
└── backend/
    ├── prisma/
    │   └── schema.prisma   # PostgreSQL Prisma ORM Database Schema
    ├── .env.example        # Environment variables configuration
    ├── package.json        # Dependencies and scripts
    └── server.js           # Node.js Express REST API
```

## Quick Start Instructions

### 1. Frontend
Simply open `frontend/index.html` in any web browser.

### 2. Backend Setup
1. Navigate to `backend/`:
   ```bash
   cd backend
   ```
2. Install dependencies:
   ```bash
   npm install
   ```
3. Configure environment variables:
   ```bash
   cp .env.example .env
   ```
   Update `DATABASE_URL` with your PostgreSQL database connection credentials.

4. Run Prisma database migrations:
   ```bash
   npx prisma migrate dev --name init
   ```

5. Start the API server:
   ```bash
   npm run dev
   ```
   The backend API will run on `http://localhost:5000`.
